package com.amzi.dao;

public class dbAccess {
    static final String url = "jdbc:mysql://localhost:3306/";
    static final String dbName = "webtestOne";
    static final String driver = "com.mysql.jdbc.Driver";
    static final String userName = "root";
    static final String password = "password";

}
