package com.amzi.dao;


import java.util.LinkedList;
import java.util.List;
 
public class toDoListList {
 
	private List<String> hour;
    private List<String> minute;
    private List<String> texts;
}
